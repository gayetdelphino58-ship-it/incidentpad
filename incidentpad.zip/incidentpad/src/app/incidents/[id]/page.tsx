"use client";

import Link from "next/link";
import { useParams } from "next/navigation";
import { useEffect, useState } from "react";
import SeverityBadge from "@/components/SeverityBadge";
import TypeIcon from "@/components/TypeIcon";
import { ensureSeeded, getIncidentById } from "@/lib/storage";
import { buildSummaryText, copyToClipboard } from "@/lib/summary";
import type { Incident } from "@/lib/types";
import { NOTIFY_LABELS } from "@/lib/types";

function formatWhen(iso: string): string {
  try {
    return new Date(iso).toLocaleString(undefined, {
      dateStyle: "medium",
      timeStyle: "short",
    });
  } catch {
    return iso;
  }
}

export default function IncidentDetailPage() {
  const params = useParams();
  const id = typeof params.id === "string" ? params.id : "";
  const [incident, setIncident] = useState<Incident | null | undefined>(
    undefined
  );
  const [copied, setCopied] = useState(false);
  const [copyError, setCopyError] = useState(false);

  useEffect(() => {
    ensureSeeded();
    setIncident(getIncidentById(id) ?? null);
  }, [id]);

  async function handleCopy() {
    if (!incident) return;
    setCopyError(false);
    const ok = await copyToClipboard(buildSummaryText(incident));
    if (ok) {
      setCopied(true);
      window.setTimeout(() => setCopied(false), 2500);
    } else {
      setCopyError(true);
    }
  }

  if (incident === undefined) {
    return (
      <div className="card p-8 text-center text-sm text-slate-500">
        Loading summary…
      </div>
    );
  }

  if (incident === null) {
    return (
      <div className="card space-y-4 p-8 text-center">
        <p className="font-medium text-slate-900">Incident not found</p>
        <p className="text-sm text-slate-600">
          This ID is not in local storage. Try Reports or reset the demo.
        </p>
        <Link href="/reports" className="btn-primary inline-flex">
          Back to reports
        </Link>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {copied && (
        <div
          role="status"
          className="print:hidden rounded-xl border border-emerald-200 bg-emerald-50 px-4 py-3 text-sm font-medium text-emerald-800"
        >
          Copied — summary is on your clipboard.
        </div>
      )}
      {copyError && (
        <div
          role="alert"
          className="print:hidden rounded-xl border border-amber-200 bg-amber-50 px-4 py-3 text-sm text-amber-900"
        >
          Could not copy automatically. Select the text below and copy manually.
        </div>
      )}

      <div className="print:hidden flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
        <Link href="/reports" className="btn-ghost self-start">
          ← Reports
        </Link>
        <div className="flex flex-col gap-2 sm:flex-row">
          <button type="button" onClick={() => window.print()} className="btn-secondary">
            Print
          </button>
          <button type="button" onClick={handleCopy} className="btn-primary">
            {copied ? "Copied" : "Copy summary"}
          </button>
        </div>
      </div>

      <article className="card overflow-hidden print:border print:shadow-none">
        <div className="border-b border-slate-100 bg-navy-950 px-5 py-5 text-white print:bg-white print:text-black sm:px-6">
          <div className="flex items-start gap-3">
            <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-white/10 print:bg-slate-100">
              <TypeIcon type={incident.type} />
            </div>
            <div className="min-w-0 flex-1">
              <p className="text-xs font-medium uppercase tracking-wide text-sky-200 print:text-slate-500">
                Incident summary
              </p>
              <h1 className="mt-0.5 text-xl font-bold tracking-tight sm:text-2xl">
                {incident.type}
              </h1>
              <div className="mt-2 flex flex-wrap items-center gap-2">
                <SeverityBadge severity={incident.severity} />
                <span className="text-xs text-slate-300 print:text-slate-500">
                  ID {incident.id}
                </span>
              </div>
            </div>
          </div>
        </div>

        <div className="space-y-5 px-5 py-5 sm:px-6">
          <dl className="grid gap-4 sm:grid-cols-2">
            <Field label="When" value={formatWhen(incident.time)} />
            <Field
              label="Trip / Load ID"
              value={incident.tripLoadId || "—"}
            />
            <Field label="Location" value={incident.location || "—"} wide />
            <Field
              label="Notify"
              value={NOTIFY_LABELS[incident.notify]}
            />
            <Field
              label="Filed"
              value={formatWhen(incident.createdAt)}
            />
          </dl>

          <section>
            <h2 className="text-xs font-semibold uppercase tracking-wide text-slate-500">
              Description
            </h2>
            <p className="mt-2 whitespace-pre-wrap text-sm leading-relaxed text-slate-800">
              {incident.description || "—"}
            </p>
          </section>

          <section>
            <h2 className="text-xs font-semibold uppercase tracking-wide text-slate-500">
              Safety checklist
            </h2>
            <ul className="mt-2 space-y-1.5 text-sm text-slate-800">
              <CheckItem
                ok={incident.checklist.truckStoppedSafely}
                label="Truck stopped safely"
              />
              <CheckItem
                ok={incident.checklist.photosNoted}
                label="Photos noted"
              />
              <CheckItem
                ok={incident.checklist.policeContacted}
                label="Police contacted"
              />
            </ul>
          </section>

          <pre className="print:hidden overflow-x-auto rounded-xl bg-slate-50 p-4 text-xs leading-relaxed text-slate-600 ring-1 ring-slate-200">
            {buildSummaryText(incident)}
          </pre>
        </div>
      </article>

      <div className="print:hidden flex gap-2">
        <Link href="/new" className="btn-primary flex-1">
          New incident
        </Link>
        <Link href="/reports" className="btn-secondary flex-1">
          All reports
        </Link>
      </div>
    </div>
  );
}

function Field({
  label,
  value,
  wide,
}: {
  label: string;
  value: string;
  wide?: boolean;
}) {
  return (
    <div className={wide ? "sm:col-span-2" : undefined}>
      <dt className="text-xs font-semibold uppercase tracking-wide text-slate-500">
        {label}
      </dt>
      <dd className="mt-1 text-sm font-medium text-slate-900">{value}</dd>
    </div>
  );
}

function CheckItem({ ok, label }: { ok: boolean; label: string }) {
  return (
    <li className="flex items-center gap-2">
      <span
        className={
          ok
            ? "flex h-5 w-5 items-center justify-center rounded-full bg-emerald-100 text-xs text-emerald-700"
            : "flex h-5 w-5 items-center justify-center rounded-full bg-slate-100 text-xs text-slate-400"
        }
      >
        {ok ? "✓" : "–"}
      </span>
      {label}
    </li>
  );
}
